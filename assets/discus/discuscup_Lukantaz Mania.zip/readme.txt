Discus Cup
Lukantaz AJAX Tutorial Mania

Kelompok: Lukantaz Mania
Anggota:
1. Jeremy Joseph Hanniel / 13510026
2. Raymond Lukanta / 13510063
3. Edward Samuel Pasaribu / 13510065

Deskripsi Singkat:
Pengenalan dan tutorial tentang AJAX yang dikemas dalam aplikasi web.

Konten:
1. Direktori "LukantazMania" : Aplikasi Web
2. AJAX Overview.docx        : Dokumentasi (overview karya)
3. readme.txt                : Tulisan ini

Aplikasi web memanfaatkan teknologi PHP, jadi untuk mencoba dapat menggunakan web server yang mendukung PHP.