 </div> </td>
       </tr>
    </table>
    </div>
    <div class="content">
      <div class="BodySegoe12MedGray" style="padding: 20px 340px 12px 12px; text-align: right">
	  	Tutorial AJAX Dasar<br />
        Copyright &copy; 2012 LukantazMania<brw />
		<a href="https://www.facebook.com/evecrest">Jeremy</a>, 
		<a href="http://www.facebook.com/raymond.lukanta">Raymond</a>, and 
		<a href="http://www.facebook.com/edward.samuel.esp">Edward</a> for Discus <a href="http://inkubatorit.com" title="Inkubator IT - Himpunan Mahasiswa Informatika ITB">iIT HMIF ITB</a> 2012</div>
    </div>
  </div>
</div>
</body>
</html>
<!--
Edward Samuel Pasaribu
-->