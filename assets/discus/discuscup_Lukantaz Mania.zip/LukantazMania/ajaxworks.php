<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./index.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./teknologi.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<h1 class="TitleSegoeLight36Orange">Cara Kerja AJAX</h1>
<p>Pada aplikasi web klasik, komunikasi antar <em>client</em> (<em>browser</em>) dengan <em>server</em> dilakukan langsung dengan menggunakan <em>HTTP Request</em>. Sedangkan aplikasi web dengan menggunakan AJAX terdapat suatu <em>layer</em> baru yang ditambahkan setelah halaman pertama kali di-<em>load</em> yang kemudian layer baru ini akan digunakan untuk client untuk berkomunikasi dengan server.</p>
<div style="text-align:center">
<img src="./images/ajax_comm_model_gif.gif" alt="Perbedaan skema komunikasi aplikasi web klasi dan yang menggunakan AJAX" />
<p><strong>Gambar 1</strong> <em>Perbedaan skema komunikasi aplikasi web klasi dan yang menggunakan AJAX</em></p>
</div>
<p>Ketika menggunakan AJAX, halaman web di-<em>load</em> secara penuh pada permintaan pertama. Di samping kode HTML dan CSS yang diunduh, kode JavaScript juga ikut diunduh, termasuk kode AJAX di dalamnya. Ketika berhasil di-<em>load</em>, mesin AJAX akan diaktifkan dan dimanfaatkan untuk me-<em>request</em> ke server baik secara sinkron maupun asinkron. Mesin AJAX ini mampu meng-<em>update</em> sebagian kecil halaman dari apa yang di-<em>response</em> oleh server.
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./index.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./teknologi.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<?php require_once("styles_bottom.php") ?>