<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./xmlhttprequest.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./sendrequest.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<h1 class="TitleSegoeLight36Orange">Membuat XMLHttpRequest Object</h1>
<p><strong>AJAX</strong> memanfaatkan <strong>XMLHttpRequest</strong> yang telah didukung pada semua "modern". Walaupun demikian IE5 dan IE6 tetap mendukung pembuatan AJAX dengan memenfaatkan <strong>ActiveXObject</strong>.</p>
<p>Seperti yang dijelaskan pada bagian <a href="./xmlhttprequest.php">sebelumnya</a>, XMLHttpRequest berfungsi untuk pertukaran data dengan server dan mengupdate sebagian halaman tanpa me-<i>load</i> ulang seluruh halaman</p>
<p>Untuk semua browser modern (IE7+, Firefox, Chrome, Safari, and Opera) maka untuk membuat XMLHttpRequest object dapat menggunakan</p>
<pre class="brush: js">
variable=new XMLHttpRequest();
</pre>
dan untuk Internet Explorer (IE5 and IE6) menggunakan</p>
<pre class="brush: js">
variable=new ActiveXObject("Microsoft.XMLHTTP");
</pre>
<p>Untuk mendukung browser modern, termasuk IE5 dan IE6, maka dapat digunakan terlebih dahulu mengecek apakah browser mendukung XMLHttpRequest seperti berikut:</p>
<p>Potongan kode pada contoh <a href="./samples.php?id=1">dasar</a>.</p>
<pre class="brush: js; first-line: 6;">
    var xmlhttp;
    if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    } else { // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
</pre>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./xmlhttprequest.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./sendrequest.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<?php require_once("styles_bottom.php") ?>