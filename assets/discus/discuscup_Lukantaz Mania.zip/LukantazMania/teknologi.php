<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./ajaxworks.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./whyajax.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
							<h1 class="TitleSegoeLight36Orange"> Teknologi AJAX </h1>
							<ol>
								<li><strong>XMLHttpRequest object (XHR)</strong><p>XHR berguna untuk mengirimkan <i>request</i> HTTP atau HTTPS secara langsung pada <i> web server</i> dan memuat respon dari <i>server</i> tersebut yang berupa data secara langsung pada <i>scripts</i>. Data yang merupakan respon <i>server</i> tersebut dapat digunakan untuk mengubah DOM secara langsung pada dokumen yang sedang aktif pada <i>browser</i> tanpa memuat dokumen web yang baru. Inilah yang membuat AJAX mampu melakukan fungsi utamanya, yaitu komunikasi asinkron.</p></li>
								<li><strong>Document Object Model (DOM)</strong><p>DOM adalah suatu konvensi yang bersifat <i>cross-platform</i> dan <i>language-independent</i> untuk mewakili dan berinteraksi dengan objek-objek dalam dokumen HTML, XHTML, dan XML. AJAX menggunakan DOM untuk tampilan dan interaksi yang dinamis dengan data.</p></li>
								<li><strong>Cascading Style Sheets (CSS)</strong><p>CSS adalah suatu <i>style sheet language</i> yang digunakan untuk menjabarkan semantik dari presentasi dokumen (tampilan dan <i>formatting</i>) yang ditulis dalam <i>markup language</i>. CSS terutama didesain untuk memungkinkan pemisahan (<i>separation</i>) isi dokumen itu sendiri dari presentasi dokumen tersebut, termasuk unsur-unsur seperti <i>layout</i>, warna, dan jenis foto. Dengan memanfaatkan CSS, AJAX dapat mengontrol <i>update</i> dari <i>data formatting</i> pada sebuah halaman <i>web</i>.</p></li>
								<li><strong>Extensible Markup Language (XML)</strong><p>XML adalah suatu <i>markup language</i> yang mendefinsikan suatu aturan untuk meng-<i>encode</i> dokumen dalam format yang <i>human-readable</i> maupun <i>machine-readable</i>. Tujuan desain dari XML menitikberatkan pada <i>simplicity</i>, <i>generality</i>, dan <i>usability</i> pada internet. AJAX menggunakan XML untuk penukaran data yang hendak di-<i>update</i>.</p></li>
								<li><strong>Extensible Stylesheet Language Transformation (XSLT)</strong><p>XSLT adalah suatu bahasa deklaratif yang berbasis XML, digunakan untuk mentransformasi dokumen-dokumen XML. Dokumen yang asli tidak diubah, melainkan suatu dokumen baru dibuat berdasarkan pada isi dokumen yang sudah ada tersebut. XLST digunakan AJAX untuk mengontrol pertukaran data dari dokumen XML.</p></li>
								<li><strong>JavaScript</strong><p>Akhirnya, AJAX menggunakan JavaScript untuk mengintegrasikan kelima teknologi di atas menjadi apa yang kita sebut AJAX.</p></li>
							</ol>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./ajaxworks.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./whyajax.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
							<?php require_once("styles_bottom.php") ?>
