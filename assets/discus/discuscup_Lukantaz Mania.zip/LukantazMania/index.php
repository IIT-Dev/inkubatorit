<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left">&nbsp;</td>
							<td style="text-align: right"><a href="./ajaxworks.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
							<h1 class="TitleSegoeLight36Orange"> Pengenalan AJAX </h1>
							<p><strong>AJAX</strong> = <em>Asynchronous JavaScript and XML</em>.</p>
							<p><strong>AJAX</strong> adalah suatu teknik untuk membuat halaman <i>web</i> yang cepat dan dinamis dengan meng-<i>update</i> sebagian kecil data pada halaman <i>web</i> dengan <i>server</i> secara asinkron di balik layar. Ini memungkinkan untuk operasi <i>update</i> bagian-bagian dari halaman <i>web</i> tanpa memuat ulang seluruh halaman itu sendiri. </p>
							<p> <strong>AJAX</strong> menggunakan berbagai teknologi berikut: </p>
							<ol>
								<li>XMLHttpRequest object</li>
								<li>DOM</li>
								<li>CSS</li>
								<li>XML</li>
								<li>XSLT</li>
								<li>JavaScript</li>
							</ol>
							<h2>Contoh AJAX (diambil dari <a href="./samples.php?id=1">Contoh Dasar</a>)</h2>
							<iframe src="./sample/sample01.php" frameborder="1" style="width:100%; height:300px; vertical-align:top"></iframe>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left">&nbsp;</td>
							<td style="text-align: right"><a href="./ajaxworks.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
							<?php require_once("styles_bottom.php") ?>