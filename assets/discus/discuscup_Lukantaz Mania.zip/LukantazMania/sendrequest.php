<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./createXMLHttpRequest.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./deskripsicontoh.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
	<h1 class="TitleSegoeLight36Orange">Mengirimkan Sebuah <em>Request</em> ke Server</h1>
    <br/>Untuk mengirimkan <em>request</em>, kita dapat memakai <em>method</em> <strong>open()</strong> atau <strong>send()</strong> pada objek XMLHttpRequest.
    <br/><h3>Contoh pemakaian (diambil dari Contoh <a href="./samples.php?id=1">Dasar</a>):</h3>
    <pre class="brush: js; first-line: 18"> xmlhttp.open("GET","demo.txt",true);
xmlhttp.send();
    </pre>   
    <h3>Prototipe <em>open</em> : open (<em>method,url,async</em>)</h3>
    <h4>Keterangan :</h4>
    	<ul>
        	<li>digunakan untuk menentukan <em><strong>tipe request</strong></em>, <strong>URL</strong>, dan <strong>karakteristik pemanggilan</strong> (<em>synchronous</em> atau tidak)</li>
            <li><em>method</em> diisi tipe <em>request</em>, yaitu GET atau POST.</li>
            <li><em>URL</em> diisi lokasi file tempat server. Jenis file bisa bermacam-macam, seperti .txt, .xml, .asp, .php, dan jenis file lainnya yang bisa melakukan aksi pada server sebelum mengembalikan respon.
            <br/></li>
            <li><em>async</em> diisi <em>true</em> atau <em>false</em>. Async membuat <em>script</em> lain dapat dieksekusi ketika sistem sedang menunggu respon dari server. Jika diisi "<strong>true</strong>", maka sistem akan dijalankan secara <em>asynchronous</em>. Sebaliknya, bila diisi "<strong>false</strong>", sistem akan dijalankan secara <em>synchronous</em></li>
        </ul>
    Prototipe <em>send</em> : send(<em>string</em>)
    <h4>Keterangan :</h4>
    	<ul>
        	<li>digunakan untuk mengirimkan <em>request off</em> ke server</li>
            <li><em>string</em> hanya digunakan untuk tipe <em>request</em> POST.</li>
        </ul>
    <h3>Cara Menentukan Tipe <em>Request</em> yang Harus Dipakai :</h3>
    <br/>GET lebih sederhana dan lebih cepat dibandingkan dengan POST. Tapi, kita harus memakai POST pada kondisi tertentu, antara lain :
    <ul>
    	<li>Ketika <em>cached file</em> tidak bisa digunakan, sehingga harus mengupdate dari server</li>
    	<li>Ketika mengirimkan data berukuran besar, karena tidak ada batasan ukuran data pada POST.</li>
        <li>Ketika mengirimkan masukan (<em>input</em>) dari pengguna, karena POST lebih tangguh dan aman dibandingkan dengan GET.</li>
    </ul>
    <h3>Contoh GET <em>Request</em> (diambil dari Contoh <a href="./samples.php?id=4">Metode GET</a>) :</h3> 
    <pre class="brush:js; first-line:23; highlight:25">
var namaVal = encodeURIComponent(document.getElementById("nama").value);
var nimVal = encodeURIComponent(document.getElementById("nim").value);
xmlhttp.open("GET","getdemo.php?nama=" + namaVal + "&nim=" + nimVal,true);
xmlhttp.send();</pre>

    <h3>Contoh POST <em>Request</em> (diambil dari Contoh<a href="./samples.php?id=3"> Metode POST</a>) :</h3>
    <pre class="brush:js; first-line:23; highlight:[26, 27]">
var namaVal = encodeURIComponent(document.getElementById("nama").value);
var nimVal = encodeURIComponent(document.getElementById("nim").value);
xmlhttp.open("POST","postdemo.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("nama="+namaVal+"&nim="+nimVal);</pre>
    <h3>Penjelasan sintaks <strong>setRequestHeader</strong></h3>
	Prototipe setRequestHeader : setRequestHeader(<em>header</em>,<em>value</em>)
    <h4>Keterangan :</h4>
    <ul>
    	<li>Digunakan untuk menambahkan HTTP <em>headers</em> ke <em>request</em> yang dikirim</li>
		<li><em>header</em> digunakan untuk memberi nama <em>header</em></li>
        <li><em>value</em> digunakan untuk memberi <em>header value</em></li>
    </ul>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./createXMLHttpRequest.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./deskripsicontoh.php">Lanjut &raquo;</a></td>
							</tr>
							</table>    
<?php require_once("styles_bottom.php")?>