<?php require_once("styles_top.php") ?>
<h1 class="TitleSegoeLight36Orange">About</h1>
	<p>This tutorial is especially made for such competition named "<strong>Discus Cup</strong>". We've tried our own best in order to finish this tutorial. We are all considering that we are possible to create the best tutorial project. Additionally, you have to know that our best is higher than others.</p> 
    <p>Well, now we will introduce ourselves.</p>
    <div style="text-align:center">
    <table width="100%">
       <tr><td colspan="3" style="text-align:center; padding-bottom:20px"><img src="./images/abc.jpg" width="500px"><br/></td></tr>
        <tr>
        	<td>Jeremy Joseph Haniel</td>
            <td>Raymond Lukanta</td>
            <td>Edward Samuel Pasaribu</td>
        </tr>
        <tr>
        	<td>13500026</td>
         	<td>13510063</td>
            <td>13510065</td>
        </tr>
           <tr>
        	<td><a href="https://www.facebook.com/evecrest">Facebook</a></td>
        	<td><a href="http://www.facebook.com/raymond.lukanta">Facebook</a></td>
            <td><a href="http://www.facebook.com/edward.samuel.esp">Facebook</a></td>
        </tr>
             
	</table></div>
    <p>Afterwards, we are proudly presenting the best tutorial you have ever read. After reading, we are really sure you will understand how to use Ajax.</p>
    
<?php require_once("styles_bottom.php")?>