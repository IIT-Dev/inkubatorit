<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./teknologi.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./xmlhttprequest.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
	<h1 class="TitleSegoeLight36Orange">Mengapa AJAX?</h1>
	<h2>Kelebihan</h2>
	<p>Kelebihan dan keuntungan dari AJAX adalah sebagai berikut:</p>
	<ol>
<li>Interface halaman web menjadi lebih responsif dan terasa dimuat secara instan.</li>
<li>Request halaman web dari web server menjadi lebih cepat karena untuk memuat suatu halaman, AJAX hanya perlu memuat basic scripts dan CSS files saja, sedangkan isi dari halaman tersebut dapat dimuat melalui banyak koneksi sekaligus.</li>
<li>Waiting time berkurang. Saat kita mengisi sebuah form, maka kita tidak usah menunggu sampai seluruh halaman web dimuat, namun hanya konten yang berubah saja yang perlu dimuat ulang. Pada kasus yang non-kritis, kita bahkan masih dapat melakukan pekerjaan lain saat data yang telah kita isi sedang dikirim ke server.</li>
<li>Jika suatu bagian dari halaman web mengalami error, maka bagian-bagian laindari halaman tersebut tidak terpengaruh (jika tidak terhubung secara logis) dan data yang telah dimasukkan user tidak hilang.</li>
<li>Data traffic dari dan menuju server berkurang secara signifikan karena data yang dikirim hanya data yang berubah dari halaman pada kondisi semula, bukan seluruh data halaman tersebut (CSS, gambar-gambar, dll.).</li>
</ol>
<h2>Kekurangan</h2>
	<p>Adapun kekurangan dari AJAX adalah sebagai berikut: </p>
	<ol>
	<li>
		<p>Pada <i>browser</i> yang masih menggunakan HTML sebelum HTML5, maka halaman <i>web</i> yang telah di-<i>update</i> menggunakan AJAX tidak dapat diakses lagi dengan tombol "back". Hal ini dikarenakan <i>request</i> yang dikirim AJAX tidak secara otomatis di-<i>register</i> pada <i>browser history engine</i>. Akibatnya jika tombol "back" ditekan, maka halaman <i>web</i> yang akan dimuat adalah halaman yang telah dimuat 100% yang dikunjungi paling terakhir. Hal ini juga menyebabkan kesulitan dalam menetapkan <i>bookmark</i> pada suatu kondisi tertentu pada halaman yang ter-<i>update</i>.</p></li>
		<li><p>Jika laju koneksi internet tidak memadai, maka pengiriman <i>request</i> tidak dapat menyusul kecepatan kebutuhan user. Misalnya pada suatu <i>search engine</I>yang menggunakan fitur <i>search auto-completition</i>, kita hendak mengetik "institut". Saat kita telah mengetik "ins", maka dikirimkan suatu <i>request</i> yang berisi sugesti-sugesti <I>auto-complete</i> yang misalnya berisi "insert, insulin, instalasi, dll.". Namun karena koneksi internet yang lambat, maka sugesti-sugesti tersebut dikirimkan saat kita telah selesai mengetik "institu". Tentunya ini bukanlah hal yang dikehendaki. Adapun pengiriman <i>request</i> ini memakai <i>bandwidth</i> yang signifikan, mengakibatkan waktu yang lama untuk memuat halaman. </p></li>
		</ol>
	<p>AJAX telah digunakan dan menyebar luas pada teknologi internet, misalnya pada berbagai <i>search engine</i>. AJAX juga dapat memampukan suatu halaman <i>web</i> untuk berkomunikasi dengan <i>web server</i> saat user meng-<i>input</i> data. Sugesti <i>auto-complete</i> tersebut dapat disimpan pada berbagai media seperti ASP/PHP file, bahkan suatu database.</p>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./teknologi.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./xmlhttprequest.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<?php require_once("styles_bottom.php") ?>