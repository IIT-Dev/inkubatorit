<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="SHORTCUT ICON" href="favico.png" />
<title>LukantazMania: Tutorial AJAX</title>
<meta name="author" content="Edward Samuel Pasaribu, Informatics Engineering ITB 2010" />
<link rel="stylesheet" type="text/css" href="styles.css"/>
<script type="text/javascript" src="./syntaxhighlighter/shCore.js"></script>
<script type="text/javascript" src="./syntaxhighlighter/shBrushPhp.js"></script>
<script type="text/javascript" src="./syntaxhighlighter/shBrushXml.js"></script>
<script type="text/javascript" src="./syntaxhighlighter/shBrushJScript.js"></script>
<link type="text/css" rel="stylesheet" href="./syntaxhighlighter/shCoreDefault.css"/>
<script type="text/javascript">SyntaxHighlighter.all();</script>
</head>

<body>
<div class="headerbar">
	<div class="content"><a href="index.php" title="OHU UBALA ITB 2011" target="_self"><img src="images/logo.png" alt="Edward Samuel's Website" style="border:none"/></a> </div>
</div>
<div class="menubar">
	<div class="content">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About</a></li>
		</ul>
	</div>
</div>
<div id="content" class="container">
<div class="contentbg">
<div class="content">
<div class="BodySegoe14Gray" style="padding: 18px 12px 20px 12px">
<table width="100%">
<tr>
	<td class="keepontop"><table width="180">
			<tr>
				<td width="180" class="BodySegoe12MedBlue">Pengenalan AJAX</td>
			</tr>
			<tr>
				<td><a href="./index.php">Pengertian</a></td>
			</tr>
			<tr>
			<td><a href="./ajaxworks.php">Cara Kerja</a></td>
			</tr>
			<tr>
				<td><a href="./teknologi.php">Teknologi</a></td>
			</tr>
			<tr>
				<td><a href="whyajax.php">Mengapa AJAX?</a></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="180" class="BodySegoe12MedBlue">Membuat AJAX dengan XMLHttpRequest</td>
			</tr>
			<tr>
				<td><a href="./xmlhttprequest.php">Tentang XMLHttpRequest</a></td>
			</tr>
			<tr>
				<td><a href="./createXMLHttpRequest.php">Membuat Objek XHR</a></td>
			</tr>
			<tr>
				<td><a href="./sendrequest.php">XHR Send-Request</a></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="180" class="BodySegoe12MedBlue">Contoh</td>
			</tr>
			<tr>
				<td><a href="./deskripsicontoh.php">Daftar Contoh</a></td>
			</tr>
			<tr>
				<td><a href="./samples.php?id=1">- Dasar</a></td>
			</tr>
			<tr>
				<td><a href="./samples.php?id=2">- AJAX PHP</a></td>
			</tr>
			<tr>
				<td><a href="./samples.php?id=3">- Metode Post</a></td>
			</tr>
			<tr>
				<td><a href="./samples.php?id=4">- Metode Get</a></td>
			</tr>
		</table></td>
	<td ><div class= "maxwidth" >
