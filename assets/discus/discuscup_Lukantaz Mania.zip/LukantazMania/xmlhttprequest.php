<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./whyajax.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./createXMLHttpRequest.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<h1 class="TitleSegoeLight36Orange">XMLHttpRequest (XHR)</h1>

<p><strong>XMLHttpRequest</strong> adalah suatu <i>application programming interface</i> (API) dalam <i>web browser scripting languages</i>. XHR digunakan untuk mengirimkan <i>request</i> HTTP atau HTTPS secara langsung pada <i> web server</i> dan memuat respon dari <i>server</i> tersebut yang berupa data secara langsung pada <i>scripts</i>.</p>
<p>Di bawah ini adalah penjelasan bagaimana XHR menjalankan fungsinya, yaitu mengirimkan <i>request</i> dan menangkap umpan balik dari <i>server</i>:
		
<ol>
	<li>
		<strong><i>open method</i></strong><i></i>
		<br /><i>Request</i> HTTP dan HTTPS dari objek XHR harus diinisialisasi melalui <i>open method</i>. <i>Method</i> ini harus dipanggil sebelum <i>request</i> dikirim untuk memvalidasi dan menentukan <i>request method</i>, URL, dan <i>URI user information</i> yang akan digunakan untuk <i>request</i> itu sendiri.</p>	
	</li>
	
	<li>
		<i><strong>setRequestHeader method</strong></i>
		<br />Jika inisialisasi berhasil, maka setelah itu XHR memanggil <i>method</i> ini untuk mengirim HTTP <i>headers</i> dengan <i>request</i> itu sendiri. <i>Method</i> ini harus dipanggil untuk setiap <i>header</i> yang perlu dikirim beserta <i>request</i>.</p>
	</li>
	
	<li>
		<i><strong>send method</strong></i>
		<br />Untuk mengirim sebuah HTTP <i>request</i>, maka <i>method</i> harus dipanggil. <i>Method</i> ini dapat mengirim data apapun asalkan dapat diubah menjadi teks <i>string</i>, dengan pengecualian objek dokumen DOM.</p>
	</li>
	
	<li>
		<strong><i>onreadystatechange event listener</i></strong> <br />Objek XHR memiliki <i>property readyState</i> yang berubah-ubah nilainya saat 1) <i>open method</i> berhasil dipanggil, 2) <i>send method</i> berhasil dipanggil dan HTTP <i>response header</i> telah diterima, 3) isi respon HTTP mulai dimuat, dan 4) isi respon HTTP telah berhasil dimuat seluruhnya. <i>Listener</i> ini mendeteksi perubahan-perubahan tersebut.</p>	
	</li>
	
	<li><em><strong>HTTP Response</strong></em><br />
		Setelah pemanggilan <i>send method</i> berhasil dan selesai, jika respon <i>server</i> adalah XML yang valid dan <i>Content-type header</i> yang dikirim oleh <i>server</i> dimengerti oleh <i>internet media type</i> untuk XML, maka <i>property responseXML</i> dari objek XHR akan mengandung objek dokumen DOM. <i>Property</i> lain yaitu <i>responseText</i> akan mengandung respon <i>server</i> tersebut dalam teks biasa, baik respon tersebut dikenali sebagai XML maupun tidak.
	</li>
	</ol>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./whyajax.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./createXMLHttpRequest.php">Lanjut &raquo;</a></td>
							</tr>
							</table>
<?php require_once("styles_bottom.php") ?>