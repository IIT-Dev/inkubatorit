<?php require_once("styles_top_1.php") ?>
	<table styles="background-color:#e5eecc; color:#000000; border:solid #c3c3c3 1px; margin-left:0px;" border="0">
		<tr style="padding-top: 20px">
			<td style="text-align:center; font: bold; padding-top: 20px" class="TitleSegoeLight36Orange">Source Code</td>
			<td style="text-align:center; font: bold; padding-top: 20px" class="TitleSegoeLight36Orange">Result</td>
		</tr>
		<?php
if (isset($_GET["id"])) {
$id = $_GET["id"];

if ($id==1) {
?>
		<tr>
			<td style="max-width:50%; width:50%; min-width: 50%"><b>sample01.php</b><br />
				<pre class="brush: js; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/sample01.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre></td>
			<td style="max-width:50%; width:50%; min-width: 50%"><iframe src="./sample/sample01.php" frameborder="0" style="width:100%; height:400px; vertical-align:top"></iframe></td>
		</tr>
		<?php
} else if ($id==2) {
?>
		<tr>
			<td style="max-width:50%; width:50%; min-width: 50%"><b>sample02.php</b><br />
				<pre class="brush: js; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/sample02.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre>
				<br />
				<b>gethint.php</b><br />
				<pre class="brush: php; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/gethint.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre></td>
			<td style="max-width:50%; width:50%; min-width: 50%; vertical-align:top"><iframe src="./sample/sample02.php" frameborder="0" style="width:100%; height:400px"></iframe></td>
		</tr>
		<?php
} else if ($id==3) {
?>
		<tr>
			<td style="max-width:50%; width:50%; min-width: 50%"><b>sample03.php</b><br />
				<pre class="brush: js; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/sample03.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre>
				<br />
				<b>postdemo.php</b><br />
				<pre class="brush: php; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/postdemo.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre></td>
			<td style="max-width:50%; width:50%; min-width: 50%; vertical-align:top"><iframe src="./sample/sample03.php" frameborder="0" style="width:100%; height:400px"></iframe></td>
		</tr>
		<?php
} else if ($id==4) {
?>
		<tr>
			<td style="max-width:50%; width:50%; min-width: 50%"><b>sample04.php</b><br />
				<pre class="brush: js; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/sample04.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre>
				<br />
				<b>getdemo.php</b><br />
				<pre class="brush: php; html-script: true; class-name: 'prewrap'">
<?
$file = "./sample/getdemo.php";
$f = htmlspecialchars(file_get_contents($file));
echo $f;
?>
</pre></td>
			<td style="max-width:50%; width:50%; min-width: 50%; vertical-align:top"><iframe src="./sample/sample04.php" frameborder="0" style="width:100%; height:400px"></iframe></td>
		</tr>
		<?php
}
}
?>
	</table>
	<?php require_once("styles_bottom_1.php") ?>