<?php
if ((isset($_GET["nama"])) && (isset($_GET["nim"]))) {
	echo 
	"<p>Hai <b>". $_GET["nama"] .
	"</b>! NIM kamu adalah ".  $_GET["nim"] ."</p>";
} else {
	echo "GET GAGAL";
}	
?>