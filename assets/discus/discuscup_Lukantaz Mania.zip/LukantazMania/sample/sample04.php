<html>
<head>
<script type="text/javascript">
function loadXMLDoc()
{
	var xmlhttp;
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
		}
	}
	
	var namaVal = encodeURIComponent(document.getElementById("nama").value);
	var nimVal = encodeURIComponent(document.getElementById("nim").value);
	
	xmlhttp.open("GET","getdemo.php?nama=" + namaVal + "&nim=" + nimVal,true);
	xmlhttp.send();
}
</script>
</head>
<body>
<h2>AJAX</h2>
<form>
	<table>
		<tr>
			<td style="width: 50%">Nama Lengkap</td>
			<td><input name="nama" type="text" class="inputText" 
			id="nama" size='30' autocomplete="off"/></td>
		</tr>
		<tr>
			<td>NIM</td>
			<td><input name="nim" type="text" class="inputText" 
			id="nim" size='30' maxlength="8" autocomplete="off"/></td>
		</tr>
	</table>
	<button type="button" onClick="loadXMLDoc()">Submit</button>
</form>
<div id="myDiv"></div>
</body>
</html>
