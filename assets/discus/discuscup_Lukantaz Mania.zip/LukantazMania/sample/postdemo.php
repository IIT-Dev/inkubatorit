<?php
if ((isset($_POST["nama"])) && (isset($_POST["nim"]))) {
	echo 
	"<p>Hai <b>". $_POST["nama"] .
	"</b>! NIM kamu adalah ".  $_POST["nim"] ."</p>";
} else {
	echo "POST GAGAL";
}	
?>