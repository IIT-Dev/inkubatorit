<?php require_once("styles_top.php") ?>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="./sendrequest.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./about.php">About</a></td>
							</tr>
							</table>
<h1 class="TitleSegoeLight36Orange">Deskripsi Contoh</h1>
<br/> Berikut ini terdapat 4 buah contoh implementasi AJAX yang terdiri dari :
<ol>
	<li><a href="./samples.php?id=1">Contoh Dasar</a>
    <br/>Pada contoh ini, ditunjukkan cara pemakaian AJAX.<br/>&nbsp;</li>
    <li><a href="./samples.php?id=2">Contoh AJAX PHP</a>
    <br/>Pada contoh ini, AJAX digabungkan dengan PHP.<br />&nbsp;</li>
    <li><a href="./samples.php?id=3">Contoh Penggunaan Metode POST</a>
    <br/>Pada contoh ini, ditunjukan cara penggunaan metode POST.<br/>&nbsp;</li>
    <li><a href="./samples.php?id=4">Contoh Penggunaan Metode GET</a>
    <br/>Pada contoh ini, ditunjukan penggunaan metode GET<br/>&nbsp;</li>
</ol>
							<table style="width: 100%">
							<tr>
							<td style="text-align: left"><a href="sendrequest.php">&laquo; Kembali</a></td>
							<td style="text-align: right"><a href="./about.php">About</a></td>
							</tr>
							</table>
<?php require_once("styles_bottom.php") ?>