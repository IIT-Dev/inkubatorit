<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="SHORTCUT ICON" href="favico.png" />
<title>LukantazMania: Tutorial AJAX</title>
<meta name="author" content="Edward Samuel Pasaribu, Informatics Engineering ITB 2010" />
<link rel="stylesheet" type="text/css" href="styles.css"/>
<script type="text/javascript" src="./syntaxhighlighter/shCore.js"></script>
<script type="text/javascript" src="./syntaxhighlighter/shBrushPhp.js"></script>
<script type="text/javascript" src="./syntaxhighlighter/shBrushXml.js"></script>
<script type="text/javascript" src="./syntaxhighlighter/shBrushJScript.js"></script>
<link type="text/css" rel="stylesheet" href="./syntaxhighlighter/shCoreDefault.css"/>
<script type="text/javascript">SyntaxHighlighter.all();</script>
</head>

<body>
<div class="headerbar">
	<div class="content"><a href="index.php" title="AJAX Tutorial" target="_self"><img src="images/logo.png" alt="AJAX Tutorial" style="border:none"/></a>
	</div>
</div>
<div class="menubar">
	<div class="content">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About</a></li>
		</ul>
	</div>
</div>
<div id="content" class="container1">